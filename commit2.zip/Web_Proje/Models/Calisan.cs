namespace Web_Proje_Kuafor.Models
{
    public class Calisan
    {
        public int CalisanID { get; set; }
        public required string CalisanAd { get; set; }
        public required string CalisanSoyad { get; set; }
        public required string CalisanTelefon { get; set; }
        public required string CalisanEmail { get; set; }
        public required string UzmanlikAlani { get; set; }
        public DateTime UygunSaatler {get; set;}// aralığı nasıl tutmalıyım?
    }
}