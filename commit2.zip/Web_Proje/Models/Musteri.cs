using System.ComponentModel.DataAnnotations;

namespace Web_Proje_Kuafor.Models
{
    public class Musteri
    {
        public int MUsteriID { get; set; }

        [Display(Name ="Adınız")]
        [Required(ErrorMessage ="Lütfen Adınızı Giriniz")]
        public  string MUsteriAd { get; set; }
        public  string MUsteriSoyad { get; set; }
        public  string MUsteriTelefon { get; set; }
        public  string MUsteriEmail { get; set; }
        public  string MUsteriSifre { get; set; }

        [DataType(DataType.Date)]//Sadece tarih
        [DisplayFormat(DataFormatString ="{0:dd-MM-yyyy}",ApplyFormatInEditMode =true)]
        public DateTime KayitTarihi { get; set; }
    }
}