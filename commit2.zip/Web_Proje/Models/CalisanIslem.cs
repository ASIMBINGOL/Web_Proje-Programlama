namespace Web_Proje.Models
{
    public class CalisanIslem
    {
        public int CalisanIslemID { get; set; }
        public int CalisanID { get; set; }
        public int IslemID { get; set; }
    }
}