using System.ComponentModel.DataAnnotations;

namespace Web_Proje_Kuafor.Models
{
    public class Randevu
    {
        public int RandevuID { get; set; }
        public int MusteriID { get; set; }
        public int CalisanID { get; set; }
        public int IslemID { get; set; }

        [DataType(DataType.Date)]//Sadece tarih
        [DisplayFormat(DataFormatString ="{0:dd-MM-yyyy}",ApplyFormatInEditMode =false)]
        public DateTime Tarih { get; set; }

        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString ="{0:HH-mm}",ApplyFormatInEditMode = false)]
        public DateTime Saat{ get; set; }
    }
}