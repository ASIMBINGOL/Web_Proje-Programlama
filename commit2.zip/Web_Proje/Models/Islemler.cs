namespace Web_Proje.Models
{
    public class Islemler
    {
        public int IslemID { get; set; }
        public required string IslemAdi { get; set; }
        public int Ucret { get; set; }
    }
}