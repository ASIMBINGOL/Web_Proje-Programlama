namespace Web_Proje_Kuafor.Models
{
    public class Randevu
    {
        public int RandevuId { get; set; }
        public DateTime RandevuSaati { get; set; }
    }
}