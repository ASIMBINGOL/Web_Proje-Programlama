using System.ComponentModel.DataAnnotations;

namespace Web_Proje_Kuafor.Models
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
        public required string AdminEmail { get; set; }
        public required string AdminSifre { get; set; }
    }
}