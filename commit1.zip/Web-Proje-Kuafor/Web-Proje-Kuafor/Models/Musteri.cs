namespace Web_Proje_Kuafor.Models
{
    public class Musteri
    {
        public int MUsteriId { get; set; }
        public required string MUsteriAd { get; set; }
        public required string MUsteriSoyad { get; set; }
        public required string MUsteriTelefon { get; set; }
        public required string MUsteriEmail { get; set; }
        public required string MUsteriSifre { get; set; }
    }
}