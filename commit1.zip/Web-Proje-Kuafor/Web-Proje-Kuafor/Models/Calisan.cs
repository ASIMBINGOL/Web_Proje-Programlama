namespace Web_Proje_Kuafor.Models
{
    public class Calisan
    {
        public int CalisanId { get; set; }
        public required string CalisanAd { get; set; }
        public required string CalisanSoyad { get; set; }
        public required string CalisanTelefon { get; set; }
        public required string CalisanEmail { get; set; }
        public required string UzmanlikAlani { get; set; }
        public DateTime CalismaAraligi {get; set;}
    }
}